# ういうい語 Discord Bot

Discordに投稿された「う」「い」と空白だけで構成された文字列を検出し、
`shf-spica/ui_language_translator` の復号仕様に従って原文へ戻して返信するBotです。

## 必要なもの

- Node.js 22.13.0以上
- npm
- Discord Bot

## セットアップ

### 1. `.env` を作る

`.env.example` をコピーして `.env` という名前にします。

Windows PowerShell:
```powershell
Copy-Item .env.example .env
```

macOS / Linux:
```bash
cp .env.example .env
```

`.env`を開き、次のようにBot Tokenを設定します。

```env
DISCORD_TOKEN=あなたのBotトークン
```

Tokenは他人に公開しないでください。

### 2. パッケージをインストール

```bash
npm install
```

### 3. BotをDiscordに追加

Discord Developer PortalでBotを作成し、
Bot設定の Privileged Gateway Intents から
**Message Content Intent** を有効にしてください。

Botには少なくとも以下の権限を与えてください。

- View Channels
- Send Messages
- Read Message History

### 4. 起動

```bash
npm start
```

次のように表示されれば起動成功です。

```text
Bot起動完了: BotName#0000
```

## 動作

通常のメッセージは無視します。

ういうい語が投稿されると、

```text
🔓 原文
こんにちは
```

のように返信します。

Bot自身のメッセージには反応しません。

## 重要

元の変換仕様は次のリポジトリに基づいています。

https://github.com/shf-spica/ui_language_translator

このBotはDiscord上で復号するだけで、元のWebアプリへメッセージを送信しません。
