import { decodeFromUi } from "./codec.js";

// 実際の変換文字列をここに入れてテストできます。
// 例:
// const result = decodeFromUi("うい うう...");
// console.log(result);

console.log("codec.ts の読み込みに成功しました。");
console.log("Discord Bot本体は npm start で起動してください。");