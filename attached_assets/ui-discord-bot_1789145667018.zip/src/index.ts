import "dotenv/config";
import { Client, GatewayIntentBits, Message } from "discord.js";
import { decodeFromUi, isUiLanguage } from "./codec.js";

const token = process.env.DISCORD_TOKEN;

if (!token) {
  console.error("DISCORD_TOKEN が設定されていません。");
  console.error(".env.example を .env にコピーしてTokenを設定してください。");
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

client.once("ready", () => {
  console.log(`Bot起動完了: ${client.user?.tag}`);
});

client.on("messageCreate", async (message: Message) => {
  if (message.author.bot) return;

  // 通常の文章は無視
  if (!isUiLanguage(message.content)) return;

  const result = decodeFromUi(message.content);

  if (result.error) {
    await message.reply(`⚠️ ういうい語を復号できませんでした。\n${result.error}`);
    return;
  }

  if (!result.text) return;

  await message.reply(`🔓 原文\n${result.text}`);
});

client.on("error", (error) => {
  console.error("Discord Client Error:", error);
});

client.login(token).catch((error) => {
  console.error("Discordへのログインに失敗しました。");
  console.error(error);
});